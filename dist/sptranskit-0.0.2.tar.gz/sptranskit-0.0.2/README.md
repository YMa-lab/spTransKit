<img src="logo/sptranskit.png" width="75px" align="left"/> spTransKit: A Toolkit for Transformation Methods in Spatial Transcriptomics 
============

This repository provides the code for the 16 transformation methods evaluated in the study: A Comprehensive Benchmarking and Practical Guide to Transformation Methods for Spatial Transcriptomics and Downstream Analyses. The methods are designed to be easily called within any spatial transcriptomics analysis pipeline.

# Table of Contents
- [Background](#background)
- [Transformations](#transformations)
- [Usage](#usage)

# Background

Spatial resolved transcriptomics (SRT) allows for the localization of gene expression to specific regions of tissue, aiding in the investigation of spatially dependent biological phenomena. Due to the many advantages of SRT over other transcriptomics technologies, several computational methods have been designed to analyze spatial transcriptomics data and extract biologically relevant spatial information. Despite the diversity of these methods, all pipelines typically begin with preprocessing of the raw expression data. Preprocessing is required to correct for the technical noise introduced by the spatial transcriptomics platform, which often obscures underlying biological signals.

# Transformations
| Name | Category | Function | Description |
|   :---:   |   :---:   |   :---:   |   :---:   |
| y/s | Library Size Factor-Based | size | Adjusts gene counts by the library size factor for each spatial location. |
| CPM | Library Size Factor-Based | cpm | Adjusts gene counts by the counts per million (CPM) library size factor for each spatial location. |
| scanpy Weinreb | Library Size Factor-Based | weinreb | Adjusts gene counts using a logarithmic shift, a size normalization for each spatial location, and a z normalization for each gene. |
| scanpy Zheng | Library Size Factor-Based | zheng | Adjusts gene counts using a size normalization, a logarithmic shift, and z normalization for each gene. |
| TMM | Library Size Factor-Based | tmm | Estimates scale factors using log-fold changes between each location and a reference, excluding genes with extreme expression. |
| DESeq2 | Library Size Factor-Based | deseq2 | Computes scale factors by comparing each gene’s expression relative to a pseudo-reference sample. |
| log(y/s + 1) | Delta Method-Based | shifted_log | Stabilizes the variance across genes. |
| log(CPM + 1) | Delta Method-Based | cpm_shifted_log | Stabilizes the variance across genes. |
| log(y/s + 1)/u | Delta Method-Based | shifted_log_size | Stabilizes the variance across genes. |
| acosh(2αy/s + 1) | Delta Method-Based | acosh | Stabilizes the variance across genes. |
| log(y/s + 1/4α) | Delta Method-Based | pseudo_shifted_log | Stabilizes the variance across genes. |
| Analytic Pearson | Model-Based | analytic_pearson | Assumes gene counts fit a negative binomial (NB) distribution, and adjusts them using a Pearson residual. |
| scanpy Pearson Residual | Model-Based | sc_pearson | Assumes gene counts fit a negative binomial (NB) distribution, and adjusts them using a Pearson residual. |
| scanpy Seurat | Model-Based | seurat | Fits a gamma-Poisson generalized linear model (GLM) to the gene counts, and adjusts them using a residual. |
| Normalisr | Model-Based | normalisr | Applies Bayesian inference to model expression variance and correct for confounding factors. |
| PsiNorm | Model-Based | psinorm | Assumes a Pareto distribution and rescales each gene’s count using a closed-form estimator of global expression based on Zipf’s Law. |

# Installation and Usage
This toolkit can be integrated into any spatial transcriptomics pipeline by simply importing the python module. To install, run:

```pip install -i https://test.pypi.org/simple/ sptranskit```

Import the transformations using the following line of code:

```import sptranskit.transformations as sp```

Each transformation takes in a scanpy AnnData object, where the gene count matrix is formatted as an N x G numpy array. 